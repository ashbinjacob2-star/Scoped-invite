#!/usr/bin/env node
'use strict';

// Scoped Invite API — hardened single-process JSON implementation.
// Requires Node.js 20+. Keep one server process and use persistent local storage.

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const DB_FILE = path.resolve(process.env.DB_FILE || path.join(__dirname, 'scoped-invite-db.json'));
const API_KEY = process.env.API_KEY || '';
const ALLOWED_ORIGINS = new Set((process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean));
const MAX_BODY_BYTES = 10 * 1024;
const MAX_EVENTS = 5000;
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = 30;
const IS_PROD = process.env.NODE_ENV === 'production';
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const MIN_LEVEL = LEVELS[process.env.LOG_LEVEL || 'info'] ?? 20;

function log(level, message, context = {}) {
  if ((LEVELS[level] ?? 40) < MIN_LEVEL) return;
  const record = { time: new Date().toISOString(), level: level.toUpperCase(), message,
    request_id: context.request_id, ...context };
  const line = JSON.stringify(record, (_k, v) => v instanceof Error ? { name: v.name, message: v.message } : v);
  (level === 'error' || level === 'warn' ? process.stderr : process.stdout).write(line + '\n');
}
const uuid = () => crypto.randomUUID();
const nowISO = () => new Date().toISOString();
const clone = x => JSON.parse(JSON.stringify(x));
const EMPTY_DB = () => ({
  groups: [], invite_links: [], invite_scopes: [], approval_events: [],
  invitee_profiles: [], invitee_memberships: [], admin_contacts: []
});
let db = EMPTY_DB();
let writeQueue = Promise.resolve();
const rateBuckets = new Map();

function validateDB(candidate) {
  if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) throw new Error('Invalid database root');
  for (const key of Object.keys(EMPTY_DB())) {
    if (!Array.isArray(candidate[key])) throw new Error(`Invalid database collection: ${key}`);
  }
  return candidate;
}
function loadDB() {
  if (!fs.existsSync(DB_FILE)) { db = EMPTY_DB(); return; }
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    db = validateDB(parsed);
  } catch (e) {
    // Fail closed. Do not silently overwrite a corrupt database.
    throw new Error(`Cannot load database safely (${DB_FILE}): ${e.message}`);
  }
}
function persistSnapshot(snapshot) {
  const dir = path.dirname(DB_FILE);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const tmp = `${DB_FILE}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  let fd;
  try {
    fd = fs.openSync(tmp, 'wx', 0o600);
    fs.writeFileSync(fd, JSON.stringify(snapshot, null, 2));
    fs.fsyncSync(fd);
    fs.closeSync(fd); fd = undefined;
    fs.renameSync(tmp, DB_FILE);
    // Best-effort directory fsync on platforms that support it.
    try { const dfd = fs.openSync(dir, 'r'); fs.fsyncSync(dfd); fs.closeSync(dfd); } catch {}
  } catch (e) {
    if (fd !== undefined) try { fs.closeSync(fd); } catch {}
    try { fs.unlinkSync(tmp); } catch {}
    throw e;
  }
}
function saveDB() {
  // Serializes writes within this process; this is NOT multi-process locking.
  const snapshot = clone(db);
  const task = writeQueue.then(() => persistSnapshot(snapshot));
  writeQueue = task.catch(() => {});
  return task;
}
function mutate(fn) {
  // Serialize read-modify-write operations to prevent lost updates in one process.
  const task = writeQueue.then(async () => {
    const before = clone(db);
    try {
      const result = await fn();
      persistSnapshot(db);
      return result;
    } catch (e) {
      db = before;
      throw e;
    }
  });
  writeQueue = task.catch(() => {});
  return task;
}
function sendJSON(res, status, data) {
  if (res.headersSent || res.writableEnded) return;
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' });
  res.end(body);
}
function sendError(res, status, code, message) { sendJSON(res, status, { error: code, message }); }
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c]);
}
function isObject(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
function validId(v) { return typeof v === 'string' && v.length >= 1 && v.length <= 128 && /^[a-zA-Z0-9._:@-]+$/.test(v); }
function getClientIP(req) {
  // Never trust X-Forwarded-For unless a trusted reverse proxy is configured.
  return req.socket.remoteAddress || 'unknown';
}
function rateLimit(req, res) {
  const key = getClientIP(req);
  const now = Date.now();
  let bucket = rateBuckets.get(key);
  if (!bucket || bucket.until <= now) bucket = { count: 0, until: now + RATE_WINDOW_MS };
  bucket.count++;
  rateBuckets.set(key, bucket);
  if (rateBuckets.size > 5000) for (const [k, v] of rateBuckets) if (v.until <= now) rateBuckets.delete(k);
  if (bucket.count > RATE_MAX) {
    res.setHeader('Retry-After', String(Math.ceil((bucket.until - now) / 1000)));
    sendError(res, 429, 'rate_limited', 'Too many requests. Try again later.');
    return false;
  }
  return true;
}
function readJSON(req) {
  return new Promise((resolve, reject) => {
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    if (type !== 'application/json') return reject(Object.assign(new Error('Content-Type must be application/json'), { status: 415, code: 'unsupported_media_type' }));
    const length = Number(req.headers['content-length'] || 0);
    if (Number.isFinite(length) && length > MAX_BODY_BYTES) return reject(Object.assign(new Error('Request body too large'), { status: 413, code: 'payload_too_large' }));
    let size = 0, chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('Request body too large'), { status: 413, code: 'payload_too_large' }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch { reject(Object.assign(new Error('Malformed JSON body'), { status: 400, code: 'invalid_json' })); }
    });
    req.on('error', reject);
  });
}
function evaluate(link, group, invitee, at = new Date()) {
  const base = {
    event_id: uuid(), link_id: link.link_id, scope_id: link.scope?.scope_id || null,
    group_id: group.group_id, invitee_id: invitee.user_id, attempted_at: at.toISOString()
  };
  if (link.revoked_at) return { ...base, decision: 'auto_denied', reason_code: 'link_revoked' };
  if (link.expires_at && (!Number.isFinite(Date.parse(link.expires_at)) || Date.parse(link.expires_at) <= at.getTime()))
    return { ...base, decision: 'auto_denied', reason_code: 'link_expired' };
  if (link.join_limit != null && link.joins_count >= link.join_limit)
    return { ...base, decision: 'auto_denied', reason_code: 'cap_reached' };
  if (link.approval_policy === 'always_approve') return { ...base, decision: 'auto_approved', reason_code: 'policy_always_approve' };
  if (link.approval_policy === 'never_approve') return { ...base, decision: 'pending', reason_code: 'policy_never_approve' };

  const scope = link.scope;
  if (scope && scope.active === true && scope.auto_approve === true) {
    if (scope.max_auto_approvals != null && scope.auto_approvals_count >= scope.max_auto_approvals)
      return { ...base, decision: 'pending', reason_code: 'scope_cap_reached' };
    let matched = false;
    const p = isObject(scope.rule_params) ? scope.rule_params : {};
    if (scope.rule_type === 'member_of_group') matched = (p.group_ids || []).some(id => (invitee.member_of_group_ids || []).includes(id));
    else if (scope.rule_type === 'contact_of_admin') matched = (invitee.contact_of_admin_ids || []).length > 0;
    else if (scope.rule_type === 'domain_verified') matched = (invitee.verified_domains || []).some(d => (p.domains || []).some(a => typeof d === 'string' && typeof a === 'string' && (d.toLowerCase() === a.toLowerCase() || d.toLowerCase().endsWith('.' + a.toLowerCase()))));
    else if (scope.rule_type === 'phone_prefix') matched = (p.prefixes || []).some(pre => typeof pre === 'string' && invitee.phone_e164.startsWith(pre));
    else if (scope.rule_type === 'any') matched = true;
    if (matched) return { ...base, decision: 'auto_approved', reason_code: 'scope_match', matched_rule: scope.rule_type };
  }
  if (link.approval_policy === 'inherit_group' && group.approve_new_participants === false)
    return { ...base, decision: 'auto_approved', reason_code: 'group_open_enrollment' };
  return { ...base, decision: 'pending', reason_code: 'requires_manual_approval' };
}
function seedDB() {
  const g1 = uuid(), g2 = uuid(), g3 = uuid();
  db.groups.push(
    { group_id: g1, name: 'Discussion', approve_new_participants: true },
    { group_id: g2, name: 'Open Group', approve_new_participants: false },
    { group_id: g3, name: 'Announcements', approve_new_participants: false }
  );
  db.invitee_profiles.push(
    { user_id: 'alice', phone_e164: '+971501111111', verified_domains: [] },
    { user_id: 'bob', phone_e164: '+1555000000', verified_domains: [] },
    { user_id: 'carol', phone_e164: '+1555000001', verified_domains: [] },
    { user_id: 'dave', phone_e164: '+1555000002', verified_domains: ['acme.com'] }
  );
  db.invitee_memberships.push({ user_id: 'bob', group_id: g3 });
  db.admin_contacts.push({ admin_id: 'admin-1', user_id: 'alice' });
  const mkLink = (code, group, scope = null, overrides = {}) => {
    const id = uuid();
    db.invite_links.push({ link_id: id, code, group_id: group, approval_policy: 'inherit_group', joins_count: 0, ...overrides });
    if (scope) db.invite_scopes.push({ scope_id: uuid(), link_id: id, ...scope });
  };
  // Demo codes are only seeded outside production; production deployments should provision real random codes.
  mkLink('AbCdEfGhIjKlMnOpQrStUv', g1, { rule_type:'contact_of_admin', rule_params:{ admin_scope:'creator' }, auto_approve:true, max_auto_approvals:200, auto_approvals_count:0, active:true });
  mkLink('ZzYyXxWwVvUuTtSsRrQqPp', g1, { rule_type:'member_of_group', rule_params:{ group_ids:[g3] }, auto_approve:true, max_auto_approvals:null, auto_approvals_count:0, active:true });
  mkLink('MmNnBbVvCcXxZzLlKkJjHh', g1, { rule_type:'phone_prefix', rule_params:{ prefixes:['+971'] }, auto_approve:false, max_auto_approvals:null, auto_approvals_count:0, active:true });
  mkLink('PpQqRrSsTtUuVvWwXxYyZz', g1, null, { approval_policy:'never_approve' });
  mkLink('AaBbCcDdEeFfGgHhIiJjKk', g2, null);
  mkLink('RrSsTtUuVvWwXxYyZzAaBb', g1, null, { revoked_at:nowISO() });
  mkLink('VvWwXxYyZzAaBbCcDdEeFf', g1, { rule_type:'contact_of_admin', rule_params:{ admin_scope:'creator' }, auto_approve:true, max_auto_approvals:10, auto_approvals_count:10, active:true });
}
function htmlPage() {
  // No secret is delivered to the browser. Admin APIs require Authorization header supplied by an operator.
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Scoped Invite API</title><style>
:root{font-family:system-ui,sans-serif;color:#17202a;background:#f3f5f7}body{margin:0;padding:24px}.wrap{max-width:1000px;margin:auto}h1{font-size:24px;margin-bottom:4px}.sub{color:#65717d;margin-top:0}.panel{background:#fff;border:1px solid #e1e6ea;border-radius:14px;padding:20px;margin:18px 0;box-shadow:0 3px 14px #14212b0a}.row{display:flex;gap:12px;align-items:end;flex-wrap:wrap}.field{flex:1;min-width:180px}label{display:block;font-size:12px;font-weight:700;margin:8px 0}input,select{width:100%;box-sizing:border-box;padding:11px;border:1px solid #cbd3da;border-radius:8px;background:white}button{padding:11px 15px;border:0;border-radius:8px;background:#146c54;color:white;font-weight:700;cursor:pointer}.secondary{background:#e9eef1;color:#17202a}.out{background:#101820;color:#e5edf2;padding:14px;border-radius:9px;white-space:pre-wrap;overflow:auto;margin-top:12px;font-size:12px}table{width:100%;border-collapse:collapse;margin-top:12px;font-size:13px}th,td{text-align:left;padding:10px;border-bottom:1px solid #edf0f2}th{background:#f7f9fa;color:#596672}.tablewrap{overflow:auto}.muted{color:#65717d;font-size:13px}
</style></head><body><main class="wrap"><h1>Scoped Invite API</h1><p class="sub">Invite evaluation and administrative review</p>
<section class="panel"><h2>Simulate a join</h2><p class="muted">This demo form calls the public join endpoint. Replace seeded demo codes before real deployment.</p><div class="row"><div class="field"><label for="code">Invite code</label><input id="code" autocomplete="off" placeholder="Paste invite code"></div><div class="field"><label for="userId">Invitee ID</label><input id="userId" maxlength="128" placeholder="e.g. alice"></div><button id="join">Join</button></div><pre id="joinOut" class="out">Result will appear here.</pre></section>
<section class="panel"><h2>Approval events</h2><p class="muted">Admin API key is entered locally and stored only in this page's memory.</p><div class="row"><div class="field"><label for="adminKey">Admin API key</label><input id="adminKey" type="password" autocomplete="off" placeholder="Enter API_KEY"></div><button class="secondary" id="refresh">Refresh</button></div><div id="events" class="tablewrap"><p class="muted">Enter an admin key to load events.</p></div></section></main>
<script>
const $=id=>document.getElementById(id);
let adminKey='';
function el(tag,text){const n=document.createElement(tag);n.textContent=text;return n;}
async function api(url,options={}){const r=await fetch(url,{...options,headers:{...(options.headers||{}),...(adminKey?{Authorization:'Bearer '+adminKey}:{})}});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.message||d.error||'Request failed ('+r.status+')');return d;}
$('join').addEventListener('click',async()=>{try{const d=await api('/api/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:$('code').value,user_id:$('userId').value})});$('joinOut').textContent=JSON.stringify(d,null,2);}catch(e){$('joinOut').textContent=e.message;}});
function actionButton(label,id,action){const b=el('button',label);b.className='secondary';b.addEventListener('click',async()=>{try{await api('/api/events/'+encodeURIComponent(id)+'/'+action,{method:'POST'});await loadEvents();}catch(e){alert(e.message)}});return b;}
async function loadEvents(){adminKey=$('adminKey').value;if(!adminKey){$('events').replaceChildren(el('p','Enter an admin key to load events.'));return;}try{const data=await api('/api/events');const table=document.createElement('table');const head=document.createElement('thead'),hr=document.createElement('tr');for(const t of ['Decision','Invitee','Group','Reason','Actions'])hr.append(el('th',t));head.append(hr);table.append(head);const body=document.createElement('tbody');for(const e of data){const tr=document.createElement('tr');for(const v of [e.decision,e.invitee_id,e.group_name,e.reason_code||'-'])tr.append(el('td',v));const td=document.createElement('td');if(e.decision==='pending'){td.append(actionButton('Approve',e.event_id,'approve'),document.createTextNode(' '),actionButton('Deny',e.event_id,'deny'));}else td.textContent='—';tr.append(td);body.append(tr);}table.append(body);$('events').replaceChildren(table);}catch(e){$('events').replaceChildren(el('p',e.message));}}
$('refresh').addEventListener('click',loadEvents);
</script></body></html>`;
}
function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  res.setHeader('Cache-Control', 'no-store');
}
function authorize(req) {
  if (!API_KEY || API_KEY.length < 32) return false;
  const header = req.headers.authorization || '';
  const match = /^Bearer ([^\s]+)$/.exec(header);
  if (!match) return false;
  const a = Buffer.from(match[1]), b = Buffer.from(API_KEY);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const server = http.createServer(async (req, res) => {
  const requestId = uuid(), started = process.hrtime.bigint();
  const finishLog = () => log('info', 'HTTP request', { request_id: requestId, method:req.method, url:req.url, status_code:res.statusCode,
    duration_ms:Number(process.hrtime.bigint()-started)/1e6, ip:getClientIP(req) });
  res.on('finish', finishLog);
  securityHeaders(res);
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.has(origin)) res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') {
    if (origin && !ALLOWED_ORIGINS.has(origin)) return sendError(res, 403, 'origin_denied', 'Origin is not allowed.');
    res.writeHead(204); return res.end();
  }
  let pathname;
  try { pathname = new URL(req.url, 'http://localhost').pathname; }
  catch { return sendError(res, 400, 'bad_url', 'Invalid URL.'); }
  try {
    if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html')) {
      res.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); return res.end(htmlPage());
    }
    if (pathname.startsWith('/api/') && pathname !== '/api/join' && !authorize(req)) {
      log('warn', 'Unauthorized admin API access', { request_id:requestId, pathname });
      return sendError(res, 401, 'unauthorized', 'Valid admin bearer token required.');
    }
    if (req.method === 'POST' && pathname === '/api/join') {
      if (!rateLimit(req, res)) return;
      const data = await readJSON(req);
      if (!isObject(data) || !validId(data.user_id) || typeof data.code !== 'string' || data.code.length < 12 || data.code.length > 128) {
        return sendError(res, 400, 'invalid_input', 'Provide a valid user_id and invite code.');
      }
      const result = await mutate(() => {
        const link = db.invite_links.find(l => l.code === data.code);
        if (!link) return { status:404, body:{error:'link_not_found',message:'Invite link not found.'} };
        const group = db.groups.find(g => g.group_id === link.group_id);
        if (!group) return { status:409, body:{error:'invalid_link_configuration',message:'Invite link references a missing group.'} };
        const profile = db.invitee_profiles.find(p => p.user_id === data.user_id) || {};
        const invitee = {
          user_id:data.user_id, phone_e164:typeof profile.phone_e164==='string'?profile.phone_e164:'',
          verified_domains:Array.isArray(profile.verified_domains)?profile.verified_domains:[],
          member_of_group_ids:db.invitee_memberships.filter(m=>m.user_id===data.user_id).map(m=>m.group_id),
          contact_of_admin_ids:db.admin_contacts.filter(c=>c.user_id===data.user_id).map(c=>c.admin_id)
        };
        const scope = db.invite_scopes.find(s=>s.link_id===link.link_id);
        const ev = evaluate(scope ? {...link,scope} : link,group,invitee);
        db.approval_events.push(ev);
        if (db.approval_events.length > MAX_EVENTS) db.approval_events.splice(0, db.approval_events.length-MAX_EVENTS);
        if (ev.decision === 'auto_approved') {
          link.joins_count = Number(link.joins_count || 0) + 1;
          if (scope && ev.reason_code === 'scope_match') scope.auto_approvals_count = Number(scope.auto_approvals_count || 0) + 1;
          if (!db.invitee_memberships.some(m=>m.user_id===data.user_id && m.group_id===group.group_id))
            db.invitee_memberships.push({user_id:data.user_id,group_id:group.group_id});
        }
        return {status:200,body:ev};
      });
      return sendJSON(res,result.status,result.body);
    }
    if (req.method === 'GET' && pathname === '/api/events') {
      const events = db.approval_events.slice(-50).reverse().map(e=>({...e,group_name:db.groups.find(g=>g.group_id===e.group_id)?.name || 'Unknown'}));
      return sendJSON(res,200,events);
    }
    const match = /^\/api\/events\/([a-f0-9-]{36})\/(approve|deny)$/.exec(pathname);
    if (req.method === 'POST' && match) {
      const [, id, action] = match;
      const result = await mutate(() => {
        const ev = db.approval_events.find(e=>e.event_id===id);
        if (!ev || ev.decision !== 'pending') return {status:404,body:{error:'pending_event_not_found',message:'Pending event not found.'}};
        const link = db.invite_links.find(l=>l.link_id===ev.link_id);
        if (action === 'approve') {
          if (!link || link.revoked_at || (link.expires_at && Date.parse(link.expires_at)<=Date.now()) ||
              (link.join_limit != null && link.joins_count >= link.join_limit)) {
            ev.decision='manually_denied'; ev.reason_code='link_unavailable_at_decision'; ev.decided_at=nowISO();
            return {status:409,body:{error:'link_unavailable',message:'Invite link is expired, revoked, missing, or at its join cap.'}};
          }
          ev.decision='manually_approved'; ev.decided_at=nowISO();
          link.joins_count=Number(link.joins_count||0)+1;
          if (!db.invitee_memberships.some(m=>m.user_id===ev.invitee_id && m.group_id===ev.group_id))
            db.invitee_memberships.push({user_id:ev.invitee_id,group_id:ev.group_id});
        } else { ev.decision='manually_denied'; ev.decided_at=nowISO(); }
        return {status:200,body:{success:true,event:ev}};
      });
      return sendJSON(res,result.status,result.body);
    }
    if (req.method === 'GET' && pathname === '/healthz') return sendJSON(res,200,{status:'ok'});
    return sendError(res,404,'not_found','Route not found.');
  } catch (e) {
    if (res.writableEnded || res.destroyed) return;
    const status = e.status || 500;
    if (status >= 500) log('error','Request failed',{request_id:requestId,error:e.message});
    return sendError(res,status,e.code || 'internal_error',status >= 500 ? 'Internal server error.' : e.message);
  }
});
server.requestTimeout = 15_000;
server.headersTimeout = 10_000;
server.keepAliveTimeout = 5_000;

function initialize() {
  if (IS_PROD && API_KEY.length < 32) throw new Error('Set API_KEY to a random secret of at least 32 characters in production.');
  loadDB();
  if (db.invite_links.length === 0 && !IS_PROD) {
    seedDB();
    persistSnapshot(db);
    log('info','Development demo data seeded');
  }
}
if (require.main === module) {
  try {
    initialize();
    server.listen(PORT, HOST, () => log('info','Server listening',{host:HOST,port:PORT,db_file:DB_FILE,environment:process.env.NODE_ENV||'development'}));
  } catch (e) {
    log('error','Startup failed',{error:e.message});
    process.exitCode=1;
  }
  const shutdown = signal => {
    log('info','Shutdown requested',{signal});
    server.close(() => { writeQueue.finally(()=>process.exit(0)); });
    setTimeout(()=>process.exit(1),10_000).unref();
  };
  process.on('SIGTERM',()=>shutdown('SIGTERM'));
  process.on('SIGINT',()=>shutdown('SIGINT'));
}
module.exports = { evaluate, escapeHTML, validateDB, readJSON, server, loadDB, saveDB };
