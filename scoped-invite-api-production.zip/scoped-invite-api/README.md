# Scoped Invite API (hardened JSON edition)

Requires **Node.js 20+**. This is a single-process implementation using Node's built-in modules only.

## Setup

1. Put `server.js` and `server.test.js` in the same folder.
2. Set a strong admin key. Generate one with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`.
3. Set environment variables and start the server.

Linux/macOS:
```sh
export NODE_ENV=production
export API_KEY='paste-a-random-secret-of-at-least-32-characters'
export PORT=3000
export HOST=127.0.0.1
node server.js
```

PowerShell:
```powershell
$env:NODE_ENV="production"
$env:API_KEY="paste-a-random-secret-of-at-least-32-characters"
$env:PORT="3000"
$env:HOST="127.0.0.1"
node server.js
```

For local testing, omit `NODE_ENV=production`; development mode seeds demo data into `scoped-invite-db.json` on first run. **Do not expose the demo codes or demo data in a real deployment.** Production starts with an empty database; provision groups, links, profiles, and scopes through a trusted administrative process before use. This sample intentionally does not provide a public admin mutation endpoint.

The server binds to `127.0.0.1` by default. Put it behind a correctly configured TLS reverse proxy for external access. If using a reverse proxy, configure it to limit request sizes and timeouts. Do not set `HOST=0.0.0.0` unless the network and firewall are configured intentionally.

Optional:
- `DB_FILE`: database file path (default `./scoped-invite-db.json`)
- `ALLOWED_ORIGINS`: comma-separated exact origins allowed for CORS; empty means no cross-origin origins are allowed
- `LOG_LEVEL`: `debug`, `info`, `warn`, or `error`

## API

- `GET /healthz` — health probe.
- `POST /api/join` — public join evaluation. JSON body: `{"code":"...","user_id":"..."}`.
- `GET /api/events` — admin-only, `Authorization: Bearer <API_KEY>`.
- `POST /api/events/:event_id/approve` — admin-only.
- `POST /api/events/:event_id/deny` — admin-only.

## Tests

```sh
node --test
```

## Security and operational notes

- No dependencies are required.
- Admin key is never embedded in client JavaScript. Enter it into the dashboard's password field to access admin endpoints; it remains in page memory only.
- API key is compared with `timingSafeEqual` after checking equal byte length.
- Public join requests are rate-limited by socket IP. If deployed behind a proxy, the app sees the proxy's address unless you add a carefully configured trusted-proxy mechanism; it deliberately does not trust arbitrary `X-Forwarded-For`.
- Mutations are serialized in one process and files are replaced atomically. This does **not** provide multi-process locking, distributed coordination, or guaranteed protection against every power-loss/filesystem failure. Run exactly one app process against the JSON file and use durable storage/backups.
- `MAX_EVENTS` bounds the event log in memory/on disk. Set retention policy to match legal/audit requirements before use.
- The CSP allows inline scripts/styles because the dashboard is self-contained. For a stricter CSP, move the script and stylesheet into separate static files and remove `'unsafe-inline'`.
- The sample has no admin endpoint to create users/groups/invite links. Seed or provision those records through a trusted offline script, not by adding an unauthenticated endpoint.
- Have a security professional review the deployment and operational controls before handling sensitive or high-value access decisions.
