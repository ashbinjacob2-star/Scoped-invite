// Run with: node --test
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { evaluate, escapeHTML, validateDB } = require('./server');

const group = { group_id:'g1', approve_new_participants:true };
const invitee = { user_id:'u1', phone_e164:'+971501234567', verified_domains:['acme.com'],
  member_of_group_ids:['g2'], contact_of_admin_ids:[] };
function link(overrides={}) { return {link_id:'l1',group_id:'g1',approval_policy:'inherit_group',joins_count:0,...overrides}; }
function scope(overrides={}) { return {scope_id:'s1',active:true,auto_approve:true,auto_approvals_count:0,
  max_auto_approvals:null,rule_type:'any',rule_params:{},...overrides}; }

test('revoked link is denied before policy evaluation', () => {
  assert.equal(evaluate(link({revoked_at:new Date().toISOString(),approval_policy:'always_approve'}),group,invitee).reason_code,'link_revoked');
});
test('expired link is denied', () => {
  assert.equal(evaluate(link({expires_at:'2000-01-01T00:00:00.000Z'}),group,invitee).reason_code,'link_expired');
});
test('join limit is enforced', () => {
  assert.equal(evaluate(link({join_limit:2,joins_count:2}),group,invitee).reason_code,'cap_reached');
});
test('always_approve policy approves', () => {
  assert.equal(evaluate(link({approval_policy:'always_approve'}),group,invitee).decision,'auto_approved');
});
test('never_approve policy remains pending', () => {
  assert.equal(evaluate(link({approval_policy:'never_approve'}),group,invitee).decision,'pending');
});
test('member_of_group scope matches', () => {
  const result=evaluate({...link(),scope:scope({rule_type:'member_of_group',rule_params:{group_ids:['g2']}})},group,invitee);
  assert.equal(result.reason_code,'scope_match');
});
test('contact scope does not match an invitee without admin contact', () => {
  const result=evaluate({...link(),scope:scope({rule_type:'contact_of_admin'})},group,invitee);
  assert.equal(result.decision,'pending');
});
test('phone prefix rule matches', () => {
  const result=evaluate({...link(),scope:scope({rule_type:'phone_prefix',rule_params:{prefixes:['+971']}})},group,invitee);
  assert.equal(result.reason_code,'scope_match');
});
test('verified domain matches exact or subdomain only', () => {
  const good=evaluate({...link(),scope:scope({rule_type:'domain_verified',rule_params:{domains:['acme.com']}})},group,invitee);
  const bad=evaluate({...link(),scope:scope({rule_type:'domain_verified',rule_params:{domains:['me.com']}})},group,invitee);
  assert.equal(good.reason_code,'scope_match');
  assert.notEqual(bad.reason_code,'scope_match');
});
test('scope cap prevents auto-approval', () => {
  const result=evaluate({...link(),scope:scope({max_auto_approvals:2,auto_approvals_count:2})},group,invitee);
  assert.equal(result.reason_code,'scope_cap_reached');
});
test('open group enrollment approves inherited policy', () => {
  const result=evaluate(link(),{...group,approve_new_participants:false},invitee);
  assert.equal(result.reason_code,'group_open_enrollment');
});
test('HTML escaping blocks markup injection', () => {
  assert.equal(escapeHTML('<script>alert("x")</script>'), '&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;');
});
test('database validation rejects missing collections', () => {
  assert.throws(()=>validateDB({groups:[]}),/Invalid database collection/);
});
